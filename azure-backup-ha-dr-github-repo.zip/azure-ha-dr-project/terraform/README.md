# Terraform starter

## What it creates

- Resource group
- Virtual network and subnet
- Network security group for HTTP
- Two Ubuntu Linux VMs with SSH public-key authentication
- Standard public Load Balancer with TCP health probe and backend pool
- Cloud-init to install Nginx and show each VM's hostname

## Before running

1. Confirm the region supports the selected Ubuntu image, VM size, and availability zones.
2. Edit `variables.tf` defaults or pass values through `terraform.tfvars` (do not commit secrets).
3. Provide a valid SSH public key.
4. Inspect `main.tf`; adapt zone and SKU settings for your subscription and region.
5. Use `terraform plan` and review all changes before applying.

This starter is deliberately scoped to the HA web tier. Azure Backup and Site Recovery are separate stages requiring region-specific decisions and explicit validation of supported replication and vault configuration. Do not assume those services are provisioned by this Terraform folder.
