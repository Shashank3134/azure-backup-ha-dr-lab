# Runbook: Azure VM backup and restore validation

## Purpose

Prove that a protected workload can be recovered from a configured Azure Backup recovery point.

## Preconditions

- A Recovery Services vault and backup policy exist.
- The target VM is protected and the initial backup job has completed.
- You have permission to perform restore operations.
- Use a disposable test file or a dedicated test VM.

## File restore exercise

1. Create a non-sensitive test file, for example `/var/tmp/backup-lab-proof.txt`.
2. Add a unique test string and record its checksum.
3. Ensure a recovery point exists after the file is created.
4. Delete or move the test file only after verifying the recovery point.
5. Use the Azure Backup file recovery workflow appropriate to the OS and vault configuration.
6. Restore the file to a safe alternate path.
7. Compare the restored content/checksum with the recorded value.
8. Record the job status and time taken.

## VM restore exercise (optional)

Use the portal's supported restore workflow to create a restored VM or restore disks to an alternate resource. Validate network settings, boot, Nginx, and access before considering the test successful.

## Success criteria

- Restore job completes successfully.
- Restored file or VM is usable and verified.
- Recovery point, duration, and any limitations are documented.

## Safety

Never test by deleting production data. Restore operations may create additional disks, NICs, or VMs that incur charges. Clean up only after validating and recording evidence.
