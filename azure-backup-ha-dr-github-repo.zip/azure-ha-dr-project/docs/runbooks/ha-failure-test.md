# Runbook: High-availability backend failure test

## Purpose

Validate that the Load Balancer stops routing traffic to an unhealthy backend while another backend remains healthy.

## Preconditions

- Terraform deployment is complete.
- Both VMs show healthy in the Load Balancer backend health view.
- The public frontend responds.
- This is a lab environment; no production workload is attached.

## Procedure

1. Capture a baseline HTTP response from the Load Balancer frontend.
2. Confirm both backend instances are healthy.
3. Stop one backend VM from the Azure portal or CLI.
4. Wait for the health probe to mark it unhealthy.
5. Send repeated requests to the Load Balancer frontend.
6. Confirm requests continue to receive a valid Nginx response from the remaining backend.
7. Start the stopped VM.
8. Wait for it to return to healthy status.
9. Capture evidence and note any observed interruption.

## Success criteria

- The surviving backend remains healthy and serves the application.
- The failed backend is removed from eligible traffic while unhealthy.
- The recovered backend returns to healthy status.

## Rollback / cleanup

Start any VM stopped for the test. Verify both backends and the frontend are healthy. Record the observed behavior; do not claim zero downtime unless measured and demonstrated.
