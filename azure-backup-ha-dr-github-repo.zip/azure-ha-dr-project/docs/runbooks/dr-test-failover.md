# Runbook: Azure Site Recovery test failover

## Purpose

Validate the recovery path in the secondary region without interrupting the primary workload.

## Preconditions

- VM replication is enabled and healthy.
- A suitable recovery point is available.
- Target network mappings and recovery plan are reviewed.
- An isolated test network exists; test VMs cannot conflict with production addresses or services.
- The current Microsoft Learn workflow for the chosen VM/region is reviewed.

## Procedure

1. Check replication health and the latest recovery point.
2. Start **Test failover** using the selected recovery point and isolated test network.
3. Wait for recovered VMs to boot.
4. Validate VM status, NIC/IP configuration, Nginx service, and application response.
5. Record start/end times and any manual network or application steps.
6. Confirm the primary workload remains unaffected.
7. Use the Site Recovery cleanup test failover action to remove test resources.
8. Verify replication remains healthy after cleanup.

## Success criteria

- Test failover completes without affecting the primary workload.
- Recovered workload boots and serves the expected application.
- Recovery time and blockers are documented.
- Test resources are cleaned up.

## Important

Test failover is not the same as planned or unplanned production failover. Do not initiate an actual failover without understanding the impact, recovery plan, DNS/routing changes, data consistency, and failback process.
