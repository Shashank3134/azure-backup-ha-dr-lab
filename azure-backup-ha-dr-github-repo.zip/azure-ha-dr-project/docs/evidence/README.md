# Evidence folder

Add sanitized evidence here after you run the lab.

Suggested filenames:
- `01-architecture.png`
- `02-load-balancer-backend-health.png`
- `03-backup-job-success.png`
- `04-file-restore-validation.png`
- `05-site-recovery-replication-health.png`
- `06-test-failover-validation.png`
- `07-monitor-alert-delivery.png`

Do not commit secrets, private keys, state files, subscription/tenant identifiers, public IPs, or unredacted personal details. The repository intentionally contains no fabricated screenshots or test results.
