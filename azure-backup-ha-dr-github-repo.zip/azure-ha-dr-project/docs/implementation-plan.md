# Implementation plan

Work through the stages in order. Verify current regional support and cost before creating resources.

## Stage 0 — Planning

- [ ] Select primary and secondary Azure regions.
- [ ] Confirm VM SKU, zone, Site Recovery, and quota support.
- [ ] Set a monthly budget alert.
- [ ] Define lab RPO/RTO targets.
- [ ] Choose an SSH public key and keep the private key local.
- [ ] Create a GitHub repository and commit the reviewed starter files.

## Stage 1 — Foundation and HA web tier

- [ ] Run `az login` and select the intended subscription.
- [ ] Review `terraform/variables.tf` and set a unique resource prefix, region, and SSH public key.
- [ ] Run `terraform init`, `terraform fmt`, `terraform validate`, and `terraform plan`.
- [ ] Review the plan carefully; apply only when it matches the expected resources.
- [ ] Confirm both VMs install Nginx through cloud-init.
- [ ] Confirm the Standard Load Balancer frontend responds.
- [ ] Stop one VM and validate traffic continues through the healthy backend.
- [ ] Start the VM again and wait for probe health to recover.

## Stage 2 — Azure Backup

- [ ] Create a Recovery Services vault in the primary region.
- [ ] Configure an appropriate backup policy and retention.
- [ ] Enable backup for each VM.
- [ ] Run/verify the initial backup job.
- [ ] Create a harmless test file on a VM, back it up, remove it, and restore it.
- [ ] Record the restore point, job status, and validation result.
- [ ] Review soft delete and security settings available for the chosen vault.

## Stage 3 — Monitoring

- [ ] Create a Log Analytics workspace.
- [ ] Configure Azure Monitor alert rules for relevant VM metrics and availability signals.
- [ ] Configure backup and Site Recovery health monitoring where supported.
- [ ] Add an Action Group with a notification endpoint you control.
- [ ] Trigger a safe test alert and verify notification delivery.
- [ ] Document alert severity, threshold, and response action.

## Stage 4 — Disaster recovery

- [ ] Create/configure the Site Recovery vault and target network as required by the chosen workflow.
- [ ] Enable replication for supported VMs.
- [ ] Confirm replication health and recovery points.
- [ ] Configure recovery plan steps and network mappings.
- [ ] Run **test failover** into an isolated test network.
- [ ] Validate boot, Nginx, network dependencies, and application response.
- [ ] Clean up the test failover according to the portal workflow.
- [ ] Document measured recovery time and any data-loss observations.
- [ ] Plan failback only after reviewing the current Microsoft runbook and lab state.

## Stage 5 — Portfolio polish

- [ ] Add screenshots with sensitive values redacted.
- [ ] Complete the test matrix in `test-plan.md`.
- [ ] Add measured RPO/RTO and limitations.
- [ ] Update the README with only verified outcomes.
- [ ] Run `terraform destroy` when appropriate and check for retained billable resources.

## Cost caution

This lab can incur compute, managed disk, public IP, Load Balancer, Backup storage, Site Recovery, Log Analytics ingestion, and other charges. Pricing depends on region, configuration, data churn, retention, and duration. Check the Azure Pricing Calculator before deployment. Stop/clean up resources after tests and review vault-protected items and retained data separately.
