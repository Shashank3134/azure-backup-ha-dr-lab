# Test plan and results

Record actual results. Do not mark a test passed until you have performed it.

| ID | Scenario | Procedure | Expected result | Status | Evidence / notes |
|---|---|---|---|---|---|
| HA-01 | Normal traffic | Request the public LB frontend repeatedly | Nginx page responds | Not run | |
| HA-02 | Backend VM stopped | Stop one backend VM | Remaining healthy backend serves requests | Not run | |
| HA-03 | Backend recovers | Start stopped VM and wait for probe | Backend returns healthy | Not run | |
| BAK-01 | Initial backup | Run backup job | Job completes successfully | Not run | |
| BAK-02 | File restore | Back up, remove, then restore a test file | File contents match expected value | Not run | |
| DR-01 | Replication health | Inspect Site Recovery health and recovery points | Replication is healthy | Not run | |
| DR-02 | Test failover | Run test failover into isolated network | Recovered VM boots and app is reachable | Not run | |
| MON-01 | Alert delivery | Trigger a safe test condition | Action Group notification arrives | Not run | |
| COST-01 | Cleanup | Destroy lab resources and inspect vault items | Unneeded resources removed; retained items reviewed | Not run | |

## Recovery measurements

| Metric | Target | Observed | How measured |
|---|---|---|---|
| RPO | Define before test | Not measured | Difference between latest recoverable point and disruption |
| RTO | Define before test | Not measured | Time from declared incident to validated service |
| Restore duration | Define before test | Not measured | Restore job start to validation |
| Alert delivery | Define before test | Not measured | Trigger time to notification receipt |

## Evidence checklist

Store sanitized screenshots or notes in `docs/evidence/`. Redact subscription IDs, tenant IDs, public IPs, emails, secrets, and identifying resource names where appropriate.
