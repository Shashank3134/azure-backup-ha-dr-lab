# Architecture and design notes

## Scope

The solution is a lab-sized web workload with a redundant primary-region web tier, backup-based recovery, and a separate cross-region recovery path.

## Design decisions

1. **Two Linux web VMs:** host a basic Nginx page with distinct host identifiers so backend routing can be observed.
2. **Standard Load Balancer:** distribute HTTP requests across healthy backends using a health probe.
3. **Availability Zones:** place VMs in separate zones only if the selected region, image, SKU, and subscription support the required configuration.
4. **Azure Backup:** use a Recovery Services vault and policy to retain recovery points and restore data/VMs.
5. **Azure Site Recovery:** replicate supported VMs to a supported secondary region and use test failover before any planned/unplanned failover.
6. **Monitoring:** centralize operational signals and create alerts with an Action Group.

## Request flow

1. A user reaches the load balancer's public frontend.
2. The load balancer probes the backend VMs.
3. Traffic is distributed only to healthy backends.
4. If one VM becomes unhealthy, the other backend should continue serving requests, assuming the load balancer and remaining dependencies are healthy.

## Recovery boundaries

- **VM/process failure:** health probe and remaining VM provide local continuity.
- **Deleted file or corrupted data:** restore from Azure Backup.
- **Regional disruption:** use Azure Site Recovery to recover replicated workloads in the secondary region.
- **Application/configuration error:** rollback or redeploy may be preferable to restoring a whole VM; retain configuration in source control.

## Network and security notes

- Do not expose SSH (TCP/22) to the entire internet in a production deployment. Use Bastion, VPN, a jump host, or tightly restricted source IPs.
- The Terraform starter intentionally limits inbound web traffic to HTTP for a simple lab. For a real deployment, add HTTPS, certificates, and appropriate security controls.
- Use least-privilege Azure RBAC. Avoid hard-coded secrets and committed state files.
- Confirm region-pair availability, Site Recovery support, VM SKU support, quotas, and service limitations before implementation.

## RPO and RTO

- **RPO (Recovery Point Objective):** maximum acceptable data loss measured in time.
- **RTO (Recovery Time Objective):** target time to restore the service.
- Define target values before testing; record observed results instead of claiming assumed numbers.

Example lab targets (adjust to your workload): RPO <= 24 hours for a scheduled-backup exercise; RTO <= 60 minutes for a manually executed recovery drill. These are exercise targets, not service guarantees.
